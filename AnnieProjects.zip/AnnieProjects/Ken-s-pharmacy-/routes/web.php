<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::Get('/', 'projectController@index');
Route::Get('layouts/index', 'projectController@index' );
Route::Get('pages/generalpharmaceutical', 'projectController@generalpharmacetical');
Route::Get('pages/petfood', 'projectController@petfood');
Route::Get('pages/herbalproducts', 'projectController@herbalProducts');
Route::Get('pages/veterinarymedicine', 'projectController@veterinarymedicine');
Route::Get('pages/makeUpandCosmetics', 'projectController@makeUpandCosmetics');

Route::Get('pages/bodybuildingsupliments', 'projectController@bodybuilding');