<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\products;

class projectController extends Controller
{
    //
    public function index(){
        $product = products::all();
        return view('layouts.index')->with('products', $product);
    }

    public function layout1(){
        return view('layouts.xyz');
    }

    public function bodyBuilding(){
        $product = products::all();
        return view('pages.bodybuildingsupliments')->with('products', $product);
    }

    public function generalpharmacetical(){
        $product = products::all();
        return view('pages.generalpharmaceutical')->with('products', $product);
    }

    public function herbalProducts(){
        $product = products::all();
        return view('pages.herbalproducts')->with('products', $product);
    }

    public function petfood(){
        $product = products::all();
        return view('pages.petfood')->with('products', $product );
    }
    public function veterinarymedicine(){
        $product = products::all();
        return view('pages.veterinarymedicine')->$product;
    }
    public function makeUpandCosmetics(){
        $product = products::all();
        return view('pages.makeUpandCosmetics')->with('product', $product);
    }
}
