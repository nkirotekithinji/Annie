@extends('partials.master')

@section('content')
    <!--page header-->
    <div class="container-fluid bg-1 text-center">
        <h2>Herbal Products.</h2>
        <small>You want it all: greater performance, greater fat loss, and explosive growth. Supplements are the answer!.</small>
    </div>
    <!--end of page header-->

    <!--products-->

    <div class="container-fluid bg-3 text-center">
        <div class="row">
            <div class="col-md-2">
                <div class="thumbnail">
                    <img src="{{ url('images/hypermatrix_body.jpg') }}" alt="hyper matrix">
                    <div class="caption">
                        <p>Hyper matrix<br>Price: KSH 100</p>
                        <button type="button" class="btn btn-success">Order</button>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="thumbnail">
                    <img src="{{ url('images/amino10000_body.jpg') }}" alt="hyper matrix">
                    <div class="caption">
                        <p>Amino 1000</p>
                        <button type="button" class="btn btn-success">Order</button>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="thumbnail">
                    <img src="{{ url('images/amino10000_body.jpg') }}" alt="hyper matrix">
                    <div class="caption">
                        <p>Amino 1000</p>
                        <button type="button" class="btn btn-success">Order</button>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="thumbnail">
                    <img src="{{ url('images/amino10000_body.jpg') }}" alt="hyper matrix">
                    <div class="caption">
                        <p>Amino 1000</p>
                        <button type="button" class="btn btn-success">Order</button>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="thumbnail">
                    <img src="{{ url('images/amino10000_body.jpg') }}" alt="hyper matrix">
                    <div class="caption">
                        <p>Amino 1000</p>
                        <button type="button" class="btn btn-success">Order</button>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="thumbnail">
                    <img src="{{ url('images/amino10000_body.jpg') }}" alt="hyper matrix">
                    <div class="caption">
                        <p>Amino 1000</p>
                        <button type="button" class="btn btn-success">Order</button>
                    </div>
                </div>
            </div>
        </div>
        <!--second row-->
        <div class="row">
            <div class="col-md-2">
                <div class="thumbnail">
                    <img src="{{ url('images/hypermatrix_body.jpg') }}" alt="hyper matrix">
                    <div class="caption">
                        <p>Hyper matrix<br>Price: KSH 100</p>
                        <button type="button" class="btn btn-success">Order</button>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="thumbnail">
                    <img src="{{ url('images/amino10000_body.jpg') }}" alt="hyper matrix">
                    <div class="caption">
                        <p>Amino 1000</p>
                        <button type="button" class="btn btn-success">Order</button>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="thumbnail">
                    <img src="{{ url('images/amino10000_body.jpg') }}" alt="hyper matrix">
                    <div class="caption">
                        <p>Amino 1000</p>
                        <button type="button" class="btn btn-success">Order</button>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="thumbnail">
                    <img src="{{ url('images/amino10000_body.jpg') }}" alt="hyper matrix">
                    <div class="caption">
                        <p>Amino 1000</p>
                        <button type="button" class="btn btn-success">Order</button>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="thumbnail">
                    <img src="{{ url('images/amino10000_body.jpg') }}" alt="hyper matrix">
                    <div class="caption">
                        <p>Amino 1000</p>
                        <button type="button" class="btn btn-success">Order</button>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="thumbnail">
                    <img src="{{ url('images/amino10000_body.jpg') }}" alt="hyper matrix">
                    <div class="caption">
                        <p>Amino 1000</p>
                        <button type="button" class="btn btn-success">Order</button>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection

