@extends('partials.master')

@section('content')
    <p>Laravel novice</p>
@endsection