@extends('partials.master')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <!--banner-->
            <div class="col-md-8">
                <img  id="image1" src="{{ url('images/banner.jpg') }}" alt="Natures Ayurvedic Remedies">
                <div class="row">
                    <div class="col-md-4">
                        <img src="{{url('images/herbal.jpg')}}" alt="herbal" class="img-thumbnail">
                    </div>
                    <div class="col-md-4">
                        <img src="{{url('images/herbal1.jpg')}}" alt="herbal" class="img-thumbnail">
                    </div>
                    <div class="col-md-4">
                        <img src="{{url('images/herbal2.jpg')}}" alt="herbal" class="img-thumbnail">
                    </div>
                </div>

            </div>
            <!--/banner-->
            <!--description-->
            <div class="col-md-4 mx-auto">
                <h5 class="text-capitalize mb-4 mt-3 font-weight-bold">open hours</h5>
                <p>Mon - Fri: 8:00am - 6:00om</p>
                <p>Sat & Sun: 9:00am - 2:00pm</p>
                <p>At Kens Pharmacy we take your health as our health. Your health's important to us and we will do everything we can to help you manage it.</p>
            </div>
            <!--/description>
        </div>
        </div>
    </div>
@endsection