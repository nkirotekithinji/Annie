<!--navbar-->
<nav class="navbar navbar-expand-lg navbar-light " >
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#myNav"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <!--collapsable navbar-->
    <div class="collapse navbar-collapse" id="myNav">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item ">
                <a class="nav-link" href="{{ url('layouts/index') }}">Home </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">About</a>
            </li>
            <!--dropdown link of products-->
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="products_list" role="button" data-toggle="dropdown"
                   aria-haspopup="true" aria-expanded="false">
                    products/What we offer</a>
                <!--dropdown menu-->
                <div class="dropdown-menu" aria-labelledby="products_list">
                    @foreach($products as $product)
                        <a class="dropdown-item" href="{{ url('pages/herbalproducts') }}">{{$product->name}}</a>
                    @endforeach

                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Contact us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">FAQ</a>
            </li>
        </ul>

    </div>

</nav>