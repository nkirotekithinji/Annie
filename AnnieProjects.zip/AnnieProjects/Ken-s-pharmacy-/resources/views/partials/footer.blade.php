<hr>
<!--Footer-->
<footer class="page-footer font-small stylish-color-dark pt-4 mt-4">

    <div class="container-fluid text-center text-md-left">
        <div class="row">

            <!--First column-->
            <!--location-->
            <div class="col-md-4">
                <h5 class="text-capitalize mb-4 mt-3 font-weight-bold">Location</h5>
               <img src="{{url('images/LOGO.png')}}" alt="Natures Ayurvedic Remedies">
                <ul class="list-unstyled">
                    <p><i class="fa fa-map-marker"></i> along the coastal strip of Kenya, South Coast. We are situated in Diani, along Diani Beach Road at Baharini next to Diani Sea Resort Beach Hotel.</p>
                </ul>
            </div>
            <!--/.First column-->

            <hr class="clearfix w-100 d-md-none">

            <!--Second column-->
            <div class="col-md-4 mx-auto">
                <h5 class="text-capitalize mb-4 mt-3 font-weight-bold">Contact us</h5>
                <ul class="list-unstyled">
                    <li><i class="fa fa-envelope"></i><p>naturesayurvedicremedies@gmail.com</p></li>
                    <li><i class="fa fa-phone"></i><p>0736154683</p></li>
                </ul>

            </div>
            <!--/.Second column-->

            <hr class="clearfix w-100 d-md-none">

            <!--Third column-->
            <!--Social buttons-->
            <div class="col-md-4 mx-auto">
                <h5 class="text-capitalize mb-4 mt-3 font-weight-bold">Get social</h5>
                <ul class="list-unstyled list-inline">
                    <li class="list-inline-item">
                        <a class="btn-floating btn-sm btn-fb mx-1">
                            <i class="fa fa-facebook"> </i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a class="btn-floating btn-sm btn-tw mx-1">
                            <i class="fa fa-twitter"> </i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a class="btn-floating btn-sm btn-gplus mx-1">
                            <i class="fa fa-google-plus"> </i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a class="btn-floating btn-sm btn-li mx-1">
                            <i class="fa fa-linkedin"> </i>
                        </a>
                    </li>

                </ul>
            </div>
            <!--/.Social buttons-->

            <!--/.Fourth column-->
        </div>
    </div>
    <!--/.Footer Links-->

    <hr>

    <!--Copyright-->
    <div class="footer-copyright py-3 text-center">
        © 2018 Copyright:Natures Ayurvedic Remedies

    </div>
    <!--/.Copyright-->

</footer>
<!--/.Footer--