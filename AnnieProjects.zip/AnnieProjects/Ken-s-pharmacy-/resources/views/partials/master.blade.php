<!DOCTYPE HTML>
<html>
    <head>
        <!-- Required bootsrap meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title></title>
        <!--Bootstrap css-->
        <link rel="stylesheet" href="{{url('css/bootstrap.min.css')}}">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!--project css-->
        <link rel="stylesheet" href="{{url('css/app.css')}}">
    </head>
    <body>
    <div class="container-fluid">
        <div class="page-header">
            <div class="row">
                <div class="col-md-8">
                    <img   src="{{ url('images/LOGO.PNG') }}" alt="Natures Ayurvedic Remedies">
                </div>
                <div class="col-md-4">
                    <p><i class="fa fa-phone"></i>0736154683</p>
                </div>
            </div>
        </div>

    </div>
    @include('partials.nav')
    @yield('content')
    @include('partials.footer')

    <!--java script files.-->
    <!--jquery , then popper, then bootstrap js-->
    <script src="{{ url('js/jquery-3.3.1.min.js')}}"></script>
    <script src="{{ url('/js/popper.min.js')}}"></script>
    <script src="{{ url('js/bootstrap.min.js')}}"></script>
    </body>
</html>